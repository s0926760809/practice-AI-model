---
agent: speckit.clarify
---
